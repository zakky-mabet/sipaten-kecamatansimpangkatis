    <div id="logoff" class="modal">
        <div class="modal-content">
            <h5>Keluar Aplikasi?</h5>
        </div>
        <div class="modal-footer">
            <a class="modal-action modal-close waves-effect waves-green btn-flat">Tidak</a>
            <a href="<?php echo site_url('apps/login/signout') ?>" class="modal-action modal-close waves-effect waves-green btn-flat">Ya</a>
        </div>
    </div>

</body>
</html>